# Statistical metadata and interfaces; no numerical algorithm is implemented here.
"""
    SpectralMMControl(; kwargs...)

Collect advanced numerical options for [`fit`](@ref) and [`glm`](@ref).
Pass the result as `control=SpectralMMControl(maxiter=500, gtol=1e-8)`.
Only supplied settings are stored; omitted settings retain the selected
backend/solver defaults. Duplicating an option in `control` and direct keywords
raises `ArgumentError`. Unknown option names are rejected.

# Options

- Iteration limits: `maxiter`, `inner_maxiter`.
- Spectral approximation: `krylovdim`, `floor`, `eta_max`, `correction_tol`, `resid_tol`.
- Penalty and convergence: `ridge`, `gtol`, `relgtol`.
- Iterative solves: `preconditioner` (`:jacobi` or `:none`);
  Julia uses `krylov_reltol`/`krylov_abstol`, C++ uses `krylov_rtol`/`krylov_atol`.
- Stopping safeguards: `accept_stalled`, `step_reltol`, `stalled_relgtol`;
  C++ additionally exposes `accept_negligible`, `negligible_step_tol`.
- Solver-specific controls: `nesterov`, `line_search`, `alpha_min`,
  `backtrack_factor`, `c_armijo`, `chol_jitter`, `max_chol_tries`.

Acceptance by this container does not imply support by every solver/backend;
unsupported options raise an error during fitting. `solver`, `rank`, `backend`,
initial coefficients and inference settings are direct fitting keywords, not
control fields. See the fitting docstring for common defaults.
"""
struct SpectralMMControl{T<:NamedTuple}
    options::T
end
function SpectralMMControl(;kwargs...)
    allowed=(:maxiter,:inner_maxiter,:krylovdim,:ridge,:floor,:gtol,:relgtol,:eta_max,
        :correction_tol,:resid_tol,:nesterov,:preconditioner,:krylov_rtol,:krylov_atol,
        :krylov_reltol,:krylov_abstol,:accept_negligible,:accept_stalled,
        :negligible_step_tol,:step_reltol,:stalled_relgtol,:line_search,:alpha_min,
        :backtrack_factor,:c_armijo,:chol_jitter,:max_chol_tries)
    all(k->k in allowed,keys(kwargs)) || throw(ArgumentError("unknown control option"))
    SpectralMMControl((;kwargs...))
end
"""
    StatisticalResult <: StatsAPI.RegressionModel

Statistical result returned by the public GLM and named-family fitting routes.
Use [`coef`](@ref), [`predict`](@ref), [`fitted`](@ref), [`residuals`](@ref),
[`nobs`](@ref), and the inference/statistics accessors below.

Properties include `family`, `link`, `formula`, `coefficient_names`, `intercept`,
`objective`, `nparams`, and `backend`. `model` holds the backend result;
[`diagnostics`](@ref) returns optimization metadata. A successful fit does not
imply available inference: inspect `model.inference.status` and `.reason`.
`modelmatrix` is not implemented for this result type. Obtain results through
fitting functions rather than constructing this metadata container manually.
"""
struct StatisticalResult{M,F,L,T} <: StatsAPI.RegressionModel
    model::M
    family::F
    link::L
    formula::T
    coefficient_names::Vector{String}
    linear_predictor::Vector{Float64}
    fittedvalues::Vector{Float64}
    y::Vector{Float64}
    optimization::NamedTuple
    deviance_value::Union{Nothing,Float64}
    likelihood_value::Union{Nothing,Float64}
    intercept::Bool
end
function Base.getproperty(m::StatisticalResult,k::Symbol)
    k===:objective && return getfield(m,:optimization).objective
    k===:nparams && return length(coef(getfield(m,:model)))
    k in fieldnames(typeof(m)) && return getfield(m,k)
    getproperty(getfield(m,:model),k)
end
Base.propertynames(m::StatisticalResult,private::Bool=false) =
    (fieldnames(typeof(m))..., :objective, :nparams, propertynames(getfield(m,:model),private)...)
"""
    coef(model::StatisticalResult)

Return the coefficient vector in fitted order, including any intercept first.
"""
StatsAPI.coef(m::StatisticalResult)=coef(m.model)
"""
    nobs(model::StatisticalResult)

Return the number of observations used for fitting.
"""
StatsAPI.nobs(m::StatisticalResult)=length(m.y)
StatsAPI.response(m::StatisticalResult)=m.y
"""
    fitted(model::StatisticalResult)

Return a copy of the fitted response means (expected counts for grouped binomial).
"""
StatsAPI.fitted(m::StatisticalResult)=copy(m.fittedvalues)
"""
    residuals(model::StatisticalResult)

Return response residuals `y - fitted(model)`.
"""
StatsAPI.residuals(m::StatisticalResult)=m.y.-m.fittedvalues
StatsModels.coefnames(m::StatisticalResult)=m.coefficient_names
"""
    vcov(model::StatisticalResult)

Return the full post-fit coefficient covariance matrix. Throws an informative error if inference is disabled, skipped or unavailable; does not compute inference on demand.
"""
StatsAPI.vcov(m::StatisticalResult)=vcov(m.model)
"""
    stderror(model::StatisticalResult)

Return coefficient standard errors from stored post-fit inference. Throws if inference is unavailable; does not compute inference on demand.
"""
StatsAPI.stderror(m::StatisticalResult)=stderror(m.model)
"""
    confint(model::StatisticalResult; level=0.95)

Return a two-column matrix of lower and upper coefficient confidence limits. Requires available inference and `0 < level < 1`; uses the stored t/normal reference distribution.
"""
function StatsAPI.confint(m::StatisticalResult;level=.95)
    0<level<1 || throw(ArgumentError("level must lie in (0,1)"))
    r=_require_inference(m)
    dist=r.statistic_type=="t" ? Distributions.TDist(r.df_resid) : Normal()
    q=Distributions.cquantile(dist,(1-level)/2)
    hcat(coef(m).-q.*r.std_error,coef(m).+q.*r.std_error)
end
"""
    coeftable(model::StatisticalResult)

Return a `GLM.CoefTable` with estimates, standard errors, t/z statistics and two-sided p-values. Requires available inference.
"""
function StatsAPI.coeftable(m::StatisticalResult)
    r=_require_inference(m)
    GLM.CoefTable(hcat(coef(m),r.std_error,r.statistic,r.p_value),
        ["Estimate","Std. Error",r.statistic_type*" statistic","p-value"],
        m.coefficient_names,4,3)
end
"""
    deviance(model::StatisticalResult)

Return unscaled GLM deviance, excluding ridge penalties. Throws for residual losses and Tweedie, whose deviance is not implemented in the statistical result layer.
"""
function StatsAPI.deviance(m::StatisticalResult)
    m.deviance_value===nothing && throw(ArgumentError("deviance is not implemented for this loss"))
    m.deviance_value
end
"""
    loglikelihood(model::StatisticalResult)

Return normalized log likelihood excluding penalties, where implemented. Gaussian uses RSS/n unless dispersion is supplied; Gamma uses supplied or Pearson dispersion. Student-t includes its fixed-scale normalization constant. Throws for unsupported losses and Tweedie; returns NaN for noninteger discrete responses or unavailable dispersion.
"""
function StatsAPI.loglikelihood(m::StatisticalResult)
    m.likelihood_value===nothing && throw(ArgumentError("normalized likelihood is not implemented for this loss"))
    m.likelihood_value
end
"""
    diagnostics(model::StatisticalResult)

Return stored optimization metadata as a named tuple, including the objective,
absolute/relative gradients, convergence, iterations, solver, rank, backend,
Krylov dimension and numerical controls. Does not refit or recompute inference.
An unavailable exact stopping reason is reported explicitly.
"""
    diagnostics(m::StatisticalResult)=m.optimization

const _PUBLIC_GLM = Dict(
    :gaussian=>(:gaussian,:identity),:gaussian_log=>(:gaussian,:log),
    :bernoulli=>(:binomial,:logit),:probit=>(:binomial,:probit),
    :binomial=>(:binomial,:logit),:poisson=>(:poisson,:log),
    :gamma=>(:gamma,:log),:gamma_inverse=>(:gamma,:inverse),
    :negative_binomial=>(:negative_binomial,:log))
_xlog(a,b)=iszero(a) ? 0.0 : a*log(b)
function _fit_statistics(name,y,mu,eta,p,options,dispersion)
    if name in (:gaussian,:gaussian_log)
        dev=sum(abs2,y.-mu); scale=isnothing(dispersion) ? dev/length(y) : dispersion
        ll=iszero(scale) ? Inf : sum(logpdf(Normal(m,sqrt(scale)),v) for (m,v) in zip(mu,y))
    elseif name in (:bernoulli,:probit,:binomial)
        trials=get(options,:trials,1.)
        nt=trials isa Real ? fill(trials,length(y)) : length(trials)==1 ? fill(only(trials),length(y)) : trials
        lp=name===:probit ? Distributions.logcdf.(Normal(),eta) : [-max(-e,0)-log1p(exp(-abs(e))) for e in eta]
        lq=name===:probit ? Distributions.logcdf.(Normal(),-eta) : [-max(e,0)-log1p(exp(-abs(e))) for e in eta]
        kernel=sum(y.*lp.+(nt.-y).*lq)
        dev=2*(sum(_xlog(v,v/n)+_xlog(n-v,(n-v)/n) for (n,v) in zip(nt,y))-kernel)
        # Count likelihoods require integer responses/trials; fractional quasi-data
        # have an objective but no normalized binomial probability mass function.
        ll=all(isinteger,y) && all(isinteger,nt) ? sum(logpdf(Binomial(Int(n),.5),Int(v))+n*log(2) for (n,v) in zip(nt,y))+kernel : NaN
    elseif name===:poisson
        dev=2*sum(_xlog(v,v/m)-v+m for (v,m) in zip(y,mu))
        ll=all(isinteger,y) ? sum(logpdf(Poisson(m),v) for (m,v) in zip(mu,y)) : NaN
    elseif name in (:gamma,:gamma_inverse)
        dev=2*sum((y.-mu)./mu.-log.(y./mu))
        scale=isnothing(dispersion) ? (length(y)>p ? sum(abs2,(y.-mu)./mu)/(length(y)-p) : NaN) : dispersion
        ll=isfinite(scale) && scale>0 ? sum(logpdf(Gamma(1/scale,m*scale),v) for (m,v) in zip(mu,y)) : NaN
    elseif name===:negative_binomial
        theta=get(options,:theta,1.)
        dev=2*sum(_xlog(v,v/m)-(v+theta)*log((v+theta)/(m+theta)) for (v,m) in zip(y,mu))
        ll=all(isinteger,y) ? sum(logpdf(NegativeBinomial(theta,theta/(theta+m)),v) for (m,v) in zip(mu,y)) : NaN
    elseif name===:student_t
        nu=get(options,:nu,4.); sigma=get(options,:sigma,1.)
        dev=nothing
        ll=sum(logpdf(Distributions.TDist(nu),(v-e)/sigma)-log(sigma) for (v,e) in zip(y,eta))
    else
        return nothing,nothing
    end
    (dev===nothing ? nothing : Float64(dev)),Float64(ll)
end
function _result_metadata(raw,X,y,name,options,intercept,formula,names,settings)
    beta=coef(raw)
    eta=Vector{Float64}(intercept ? X*view(beta,2:length(beta)).+beta[1] : X*beta)
    mu=raw isa _CppBackend.FittedModel ? _CppBackend.predict(raw,X) : predict(raw)
    p=length(beta)
    solver=get(settings,:solver,:pcg); solver=solver===:spectral ? :pcg : solver===:cholesky ? :cho : solver
    rank=get(settings,:rank,nothing); rank=isnothing(rank) ? _default_rank(p) : rank
    defaults=(maxiter=200,inner_maxiter=100,gtol=1e-7,relgtol=1e-8,floor=1e-6,
        krylovdim=raw isa _CppBackend.FittedModel ? min(p,max(3*(rank+1)+20,rank+11)) : min(p,max(12,rank+1)))
    cfg=merge(defaults,settings)
    if raw isa _CppBackend.FittedModel
        i=raw.info
        reasons=("gradient tolerance reached","maximum iterations reached","line search failed","inner breakdown","negligible step","stalled near tolerance")
        reason=reasons[i.termination+1]
        diag=(solver=solver,rank=rank,converged=i.converged,termination_reason=reason,
              outer_iterations=i.iterations,inner_iterations=i.inner_iterations,gradient_norm=i.gradnorm,
              relative_gradient=i.relgradnorm,objective=i.loss,backend=:cpp)
    else
        r=raw.result
        # The old result does not retain each early-exit label. Never invent one.
        grad=last(r.gradnorms)<=cfg.gtol || last(r.relgradnorms)<=cfg.relgtol
        reason=grad ? "gradient tolerance reached" : r.iters>=cfg.maxiter ? "maximum iterations reached" :
            r.converged ? "accepted step-based termination (exact reason not retained)" : "stopped before convergence (exact reason not retained)"
        inner=hasproperty(r,:inner_iters) ? sum(r.inner_iters) : nothing
        diag=(solver=solver,rank=rank,converged=r.converged,termination_reason=reason,
              outer_iterations=r.iters,inner_iterations=inner,gradient_norm=last(r.gradnorms),
              relative_gradient=last(r.relgradnorms),objective=last(r.losses),backend=:julia)
    end
    penalty=0.5*get(settings,:ridge,0.)*sum(abs2,view(beta,(intercept && !get(settings,:penalize_intercept,false) ? 2 : 1):length(beta)))
    diag=merge(diag,(optimization_objective=diag.objective,objective=diag.objective-penalty))
    diag=merge(diag,(family_options=_display_options(name,options),krylov_dimension=cfg.krylovdim,preconditioner=get(cfg,:preconditioner,nothing),control=cfg))
    d,ll=_fit_statistics(name,y,mu,eta,p,options,get(settings,:dispersion,nothing))
    family,link=get(_PUBLIC_GLM,name,(name,nothing))
    StatisticalResult(raw,family,link,formula,String.(names),eta,Vector{Float64}(mu),Vector{Float64}(y),diag,d,ll,intercept)
end
function _statistical_fit(X,y,name;data=nothing,backend=:julia,family_options=NamedTuple(),
                          intercept=nothing,start=nothing,beta0=nothing,control=SpectralMMControl(),
                          weights=nothing,offset=nothing,kwargs...)
    weights===nothing && offset===nothing || throw(ArgumentError("observation weights and offset are not implemented by the numerical core"))
    start===nothing || beta0===nothing || throw(ArgumentError("use start or beta0, not both"))
    control isa SpectralMMControl || throw(ArgumentError("control must be SpectralMMControl"))
    isempty(intersect(keys(control.options),keys(kwargs))) || throw(ArgumentError("duplicate direct/control options"))
    settings=merge(control.options,(;kwargs...))
    f=nothing
    if X isa StatsModels.FormulaTerm
        y===nothing && data!==nothing || throw(ArgumentError("formula requires data and no separate y"))
        intercept===nothing || throw(ArgumentError("the formula controls the intercept"))
        # StatsModels does not support GLM offsets here: do not encode one as a coefficient.
        occursin(r"\boffset\s*\(",string(X)) && throw(ArgumentError("formula offsets are not implemented"))
        f=StatsModels.apply_schema(X,StatsModels.schema(X,data),SpectralGLM)
        y,X=StatsModels.modelcols(f,data)
        names=String.(StatsModels.coefnames(f.rhs))
        intercept=StatsModels.hasintercept(f)
        if intercept
            first(names)=="(Intercept)" || throw(ArgumentError("unsupported formula intercept ordering"))
            X=X[:,2:end]
        end
    else
        data===nothing || throw(ArgumentError("data= is only valid for formulas"))
        intercept=isnothing(intercept) ? true : intercept
        names=vcat(intercept ? ["(Intercept)"] : String[],["x$j" for j in 1:size(X,2)])
    end
    get(settings,:verbose,false) && _print_model_header(stdout,name,_display_options(name,family_options),length(y),size(X,2)+intercept,intercept,backend)
    raw=_fit_backend(X,y;family=name,backend,family_options,intercept,
                     beta0=isnothing(start) ? beta0 : start,settings...)
    result=_result_metadata(raw,X,y,Symbol(name),family_options,intercept,f,names,settings)
    get(settings,:verbose,false) && (println(); _print_result_inference(stdout,result))
    result
end
"""
    fit(X, y; family=:gaussian, kwargs...)
    fit(formula, data; family=:gaussian, kwargs...)
    fit(X, y, loss; kwargs...)

Fit a model from a predictor matrix and response vector, or from a StatsModels
formula and table. Matrix rows are observations. Dense and sparse real matrices
are accepted. The exported loss objects are [`PseudoHuber`](@ref),
[`Expectile`](@ref), [`SmoothQuantile`](@ref), and [`StudentT`](@ref).

# Model specification

- `family=:gaussian`: one of `:gaussian`, `:gaussian_log`, `:bernoulli`, `:probit`,
  `:poisson`, `:gamma`, `:gamma_inverse`, `:negative_binomial`, `:binomial`,
  `:tweedie`, `:pseudo_huber`, `:expectile`, `:smooth_quantile`, `:student_t`.
- `family_options=NamedTuple()`: fixed family parameters. Supported keys/defaults:
  negative binomial `(theta=1.0,)`; binomial `(trials=1.0,)` (scalar or per-row);
  Tweedie `(power=1.5,)`, with `1 < power < 2`; Pseudo-Huber `(delta=1.0,)`;
  expectile `(q=0.5,)`; smoothed quantile `(q=0.5, smoothing=0.1)`;
  Student-t `(nu=4.0, sigma=1.0)`. Binomial responses are success counts.
  With a positional loss object, specify tuning parameters in its constructor.
- `backend=:julia`: use `:cpp` for the shared C++ implementation. Its first use
  builds and caches the library and requires a C++17 compiler.
- `intercept=true`: prepend an intercept for matrix input. Set `false` for a
  complete design. Formula input controls its intercept and rejects this keyword.
- `start=nothing`: initial coefficient vector, including the intercept first.
  `beta0` is an alias; supplying both raises an error. Omission uses backend
  initialization. `weights` and `offset` are not implemented and must be `nothing`.

# Numerical options

- `solver=:pcg`: also `:mm`, `:cg`, `:cho`, `:cgls`, `:crls`, `:lsqr`, `:lsmr`;
  aliases `:spectral` and `:cholesky` select `:pcg` and `:cho`.
- `rank=nothing`: retained spectral rank; defaults to `p-1` for `p<20`, otherwise
  10, where `p` includes the intercept. Requires `1 <= rank < p` (`rank=0` for `p=1`).
- `maxiter=200`, `inner_maxiter=100`: outer and inner iteration limits.
- `gtol=1e-7`, `relgtol=1e-8`: absolute and relative gradient tolerances.
- `floor=1e-6`: positive spectral floor; `ridge=0.0`: nonnegative ridge penalty;
  `penalize_intercept=false`: exclude an automatically fitted intercept from ridge.
- `verbose=false`: print iteration diagnostics. C++ also supports `trace=false`
  to retain structured iteration rows.
- `control=SpectralMMControl()`: additional backend/solver-specific options;
  supported numerical options may also be passed directly. See [`SpectralMMControl`](@ref).

# Inference options

- `inference=:auto`: attempt inference for at most `inference_max_p=50` total
  coefficients. `true` bypasses only this size limit; `false` disables inference.
- `cov_type=:auto`: model-based for GLMs, HC1 sandwich for residual losses.
  Explicit values are `:model` or `:sandwich`, subject to family restrictions.
- `level=0.95`: confidence level; `use_t=nothing`: select the reference distribution
  automatically (`true` requests t, `false` requests normal).
- `dispersion=nothing`: estimate dispersion where applicable, or provide a
  positive fixed value for model-based covariance.

Inference is withheld for failed validity checks, including insufficient gradient
convergence, unidentified coefficients and ridge penalties. It can form dense
coefficient matrices even when fitting is matrix-free.

# Returns

A [`StatisticalResult`](@ref) for the named families and exported residual losses.
Use [`diagnostics`](@ref) to inspect convergence, and [`predict`](@ref) for
response or link predictions. Unsupported combinations raise errors.

# Example

```julia
using SpectralMM
X = [sin(i*j) for i in 1:100, j in 1:3]
y = [cos(i) for i in 1:100]
m = SpectralMM.fit(X, y, PseudoHuber(); inference=false)
coef(m)
```
"""
function fit(X::AbstractMatrix,y::AbstractVector;family=:gaussian,kwargs...)
    _statistical_fit(X,y,Symbol(family);kwargs...)
end
function fit(f::StatsModels.FormulaTerm,data;family=:gaussian,kwargs...)
    _statistical_fit(f,nothing,Symbol(family);data,kwargs...)
end
function _distribution_spec(family,link)
    if family isa NegativeBinomial && link isa GLM.LogLink
        return :negative_binomial,(theta=first(Distributions.params(family)),)
    elseif family isa Binomial
        first(Distributions.params(family))==1 || throw(ArgumentError("glm currently supports binary responses only"))
        family=Bernoulli()
    end
    internal=_glm_family(family,link)
    name=internal isa BernoulliLogit ? :bernoulli : internal isa BernoulliProbit ? :probit :
         internal isa GaussianIdentity ? :gaussian : internal isa GaussianLog ? :gaussian_log :
         internal isa PoissonLog ? :poisson : internal isa GammaLog ? :gamma : :gamma_inverse
    name,NamedTuple()
end
"""
    glm(X, y, family, link; kwargs...)
    glm(formula, data, family, link; kwargs...)

Fit a generalized linear model and return a [`StatisticalResult`](@ref).
Use distributions from Distributions.jl and links from GLM.jl:

| Distribution | Supported link objects |
|---|---|
| `Normal()` | `IdentityLink()`, `LogLink()` |
| `Bernoulli()` or `Binomial(1, 0.5)` | `LogitLink()`, `ProbitLink()` |
| `Poisson()` | `LogLink()` |
| `Gamma()` | `LogLink()`, `InverseLink()` |
| `NegativeBinomial(theta, 0.5)` | `LogLink()`; fixed positive `theta` |

Binary responses must be numeric 0/1 values. For binomial success counts with
known trials and Tweedie regression, use the named-family [`fit`](@ref) interface.
The distribution constructor's probability is not the fitted mean.

All common input, backend, solver, initialization and inference keywords are
documented under [`fit`](@ref). The distribution/link select the family parameters;
do not pass a separate `family_options` keyword. Formula fitting requires
StatsModels; the formula controls the intercept and is retained for prediction.

# Example

```julia
using SpectralMM, Distributions, GLM
X = [sin(i*j) for i in 1:100, j in 1:3]
y = Float64.(isodd.(1:100))
m = SpectralMM.glm(X, y, Bernoulli(), LogitLink(); solver=:pcg)
predict(m, X)
```
"""
function glm(X::AbstractMatrix,y::AbstractVector,family::Distribution,link::GLM.Link;kwargs...)
    name,options=_distribution_spec(family,link)
    _statistical_fit(X,y,name;family_options=options,kwargs...)
end
function glm(f::StatsModels.FormulaTerm,data,family::Distribution,link::GLM.Link;kwargs...)
    name,options=_distribution_spec(family,link)
    _statistical_fit(f,nothing,name;data,family_options=options,kwargs...)
end
function fit(X::AbstractMatrix,y::AbstractVector,family::IRLSFamily;kwargs...)
    name=family isa SmoothQuantile ? :smooth_quantile : family isa Expectile ? :expectile :
        family isa PseudoHuber ? :pseudo_huber : family isa StudentT ? :student_t :
        family isa NegativeBinomialLog ? :negative_binomial : family isa BinomialLogit ? :binomial :
        family isa TweedieLog ? :tweedie : nothing
    name===nothing && return _fit_julia(X,y,family;kwargs...)
    options=name===:smooth_quantile ? (q=family.q,smoothing=family.epsilon) :
        name===:expectile ? (q=family.q,) : name===:pseudo_huber ? (delta=family.delta,) :
        name===:student_t ? (nu=family.nu,sigma=family.sigma,) :
        name===:negative_binomial ? (theta=family.theta,) : name===:binomial ? (trials=family.n,) : (power=family.p,)
    _statistical_fit(X,y,name;family_options=options,kwargs...)
end
"""
    predict(model::StatisticalResult, newdata=nothing; type=:response, trials=nothing)

Predict response means (`type=:response`, default) or linear predictors
(`type=:link`). Omitting `newdata` returns a copy of cached training predictions.
For matrix input use the same feature order as fitting, excluding an automatically
added intercept. A formula-fitted model also accepts tables and applies its saved
schema and categorical contrasts. New feature dimensions must match.

`trials` applies only to binomial success-count models; provide a scalar or values
for the prediction rows when training trials cannot be reused. Response predictions
for these models are expected counts. Residual-loss predictions are fitted locations.
"""
function StatsAPI.predict(m::StatisticalResult,Xnew=nothing;type=:response,trials=nothing)
    type in (:response,:link) || throw(ArgumentError("type must be :response or :link"))
    Xnew===nothing && return copy(type===:response ? m.fittedvalues : m.linear_predictor)
    if !(Xnew isa AbstractMatrix)
        m.formula===nothing && throw(ArgumentError("table prediction requires a formula model"))
        Xnew=StatsModels.modelcols(m.formula.rhs,Xnew)
        m.intercept && (Xnew=Xnew[:,2:end])
    end
    beta=coef(m)
    size(Xnew,2)==length(beta)-m.intercept || throw(DimensionMismatch("prediction feature count differs from training"))
    if type===:link
        return m.intercept ? Xnew*view(beta,2:length(beta)).+beta[1] : Xnew*beta
    end
    if m.model isa SpectralGLM
        trials===nothing || throw(ArgumentError("trials only applies to grouped binomial models"))
        return predict(m.model,Xnew)
    end
    predict(m.model,Xnew;trials)
end
function _print_result_inference(io,m::StatisticalResult)
    inf=m.inference; d=diagnostics(m)
    println(io,"Inference:")
    _print_family(io,m.family,d.family_options;link=m.link)
    ok=inf.status=="ok"
    if ok
        ref=inf.statistic_type=="t" ? "t (df=$(inf.df_resid))" : "standard normal"
        println(io,"Covariance: ",inf.cov_type=="sandwich" ? "sandwich HC1" : "model-based","   Reference distribution: ",ref)
    else
        println(io,"Status: ",inf.status,"\nReason: ",inf.reason)
    end
    println(io,"\nCoefficients:")
    @printf(io,"%-24s %12s","Term","Estimate")
    ok && @printf(io," %12s %12s %10s","Std. Error",inf.statistic_type*" statistic","p-value")
    println(io)
    for j in 1:min(20,length(coef(m)))
        @printf(io,"%-24s %12.6f",m.coefficient_names[j]=="(Intercept)" ? "Intercept" : m.coefficient_names[j],coef(m)[j])
        if ok
            pv=inf.p_value[j]<.0001 ? "<0.0001" : @sprintf("%.4f",inf.p_value[j])
            @printf(io," %12.6f %12.4f %10s",inf.std_error[j],inf.statistic[j],pv)
        end
        println(io)
    end
    length(coef(m))>20 && println(io,"Additional coefficients are available in coef(model).")
end
function Base.show(io::IO,::MIME"text/plain",m::StatisticalResult)
    d=diagnostics(m); cfg=d.control
    _print_model_header(io,m.family,d.family_options,nobs(m),length(coef(m)),m.intercept,m.backend;link=m.link)
    println(io,"Solver: ",uppercase(string(d.solver)),d.solver in (:pcg,:mm) ? "   Rank: $(d.rank)" : "")
    absolute=d.gradient_norm<=cfg.gtol; relative=d.relative_gradient<=cfg.relgtol
    reason=absolute ? "absolute gradient tolerance" : relative ? "relative gradient tolerance" : d.termination_reason
    println(io,"\nStatus: ",absolute || relative ? "converged" : "terminated","\nStopping criterion: ",reason)
    println(io,"Outer iterations: ",d.outer_iterations,"   Total inner iterations: ",something(d.inner_iterations,"not recorded"))
    ll=m.likelihood_value
    metric=ll!==nothing && !isnan(ll) ? "LogLik" : "Objective"
    @printf(io,"\nFinal %s: %.6e\nGradient norm: %.3e\nRelative gradient: %.3e\n",metric,metric=="LogLik" ? ll : m.objective,d.gradient_norm,d.relative_gradient)
    println(io); _print_result_inference(io,m)
end
Base.show(io::IO,m::StatisticalResult)=show(io,MIME"text/plain"(),m)
